<?php
        
/*              
        Plugin Name: FS Tagline
        Plugin URI: https://github.com/FazleySabbir/FS-Tagline/
        Plugin Description: This plugin will give you a opportunity to add tagline on your hompage.
        Plugin Version: 1.0
        Plugin Date: 2020-07-24
        Plugin Author: Fazley Sabbir
        Plugin Author URI: https://www.facebook.com/profile.php?id=100013518669051            
        Plugin License: GPLv2                           
        Plugin Minimum Question2Answer Version: 1.5
        Plugin Update Check URI: https://raw.github.com/FazleySabbir/FS-Tagline/
*/                      
                        
                        
        if (!defined('QA_VERSION')) { // don't allow this page to be requested directly from browser
                        header('Location: ../../');
                        exit;   
        }               

        qa_register_plugin_module('module', 'fs-tagline-admin.php', 'fs_tagline_admin', 'Tagline Admin');
        
        qa_register_plugin_layer('fs-tagline-layer.php', 'Tagline Layer');
		
		
                     
                        
/*                              
        Omit PHP closing tag to help avoid accidental output
*/                              
                          

