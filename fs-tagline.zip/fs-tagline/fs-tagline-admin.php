<?php
	class fs_tagline_admin {

		function option_default($option) {
			switch($option) {
				case 'tagline_max_length':
					return 120;
				case 'site_tagline':
				    return 'The best Q2A site';
				default:
					return null;				
			}
			
		}
		
		function allow_template($template)
		{
			return ($template!='admin');
		}	   
			
		function admin_form(&$qa_content)
		{				
			
			$ok = null;
			
			if (qa_clicked('tagline_save')) {
				
				
					qa_opt('tagline_enable',(bool)qa_post_text('tagline_enable'));
					qa_opt('tagline_homepage',(bool)qa_post_text('tagline_homepage'));
					if (strlen(qa_post_text('site_tagline')) < qa_opt('tagline_max_length')) {
					qa_opt('site_tagline',qa_post_text('site_tagline'));
					}
					else { $error=1; }
					
					$ok = 'Settings Saved.';
				
			}
			
			$fields = array();
			
			$fields[] = array(
				'label' => 'Enable Tagline',
				'tags' => 'NAME="tagline_enable"',
				'value' => qa_opt('tagline_enable'),
				'type' => 'checkbox',
			);
			
			$fields[] = array(
				'label' => 'Show only on homepage',
				'tags' => 'NAME="tagline_homepage"',
				'value' => qa_opt('tagline_homepage'),
				'type' => 'checkbox',
				'note' => 'If this box is checked, the tagline will be shown only on homepage.Otherwise, it will be shown on every page.',
			);
			

			$fields[] = array(
				'label' => 'Tagline',
				'tags' => 'NAME="site_tagline"',
				'value' => qa_opt('site_tagline'),
				'type' => 'text',
				'note' => 'Maximum length must not be more than 120 characters',
			);
		  

			return array(		   
				'ok' => ($ok && !isset($error)) ? $ok : null,
			
				
				'fields' => $fields,
			 
				'buttons' => array(
					array(
						'label' => 'Save',
						'tags' => 'NAME="tagline_save"',
						'note' => 'Powered by Fazley Sabbir',
					)
				),
			);
		}
	}

