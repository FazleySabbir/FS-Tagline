<?php

	class qa_html_theme_layer extends qa_html_theme_base {

		public function head_title()
	{ 
		$pagetitle = strlen($this->request) ? strip_tags(@$this->content['title']) : '';
		$headtitle = (strlen($pagetitle) ? "$pagetitle - " : '') . $this->content['site_title'].(qa_opt('tagline_enable') ? qa_opt('tagline_homepage') ? !strlen($pagetitle) ? " - ".qa_opt('site_tagline') : '' : " - ".qa_opt('site_tagline') : '');
		$this->output('<title>' . $headtitle . '</title>');
		
	}
	}

